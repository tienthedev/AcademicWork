#ifndef STRING_UTILS_H_
#define STRING_UTILS_H_
#include <stdio.h>
#include <string.h>

#define BUF_SIZE 64

void trim(char *);

#endif
